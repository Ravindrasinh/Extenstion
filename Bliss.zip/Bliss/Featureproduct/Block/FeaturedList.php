<?php
namespace Bliss\Featureproduct\Block;
class FeaturedList extends \Magento\Framework\View\Element\Template
{
    protected $_categoryHelper;
    protected $categoryFlatConfig;
    protected $topMenu;
	protected $_categoryFactory;	
	protected $_productCollectionFactory;
	protected $scopeConfig;
    


   
    /**
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Magento\Catalog\Helper\Category $categoryHelper
     * @param array $data
     */
    public function __construct(
      
		\Magento\Backend\Block\Template\Context $context,        
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory, 
		\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,      		
        array $data = []
    )
    {
       
		$this->_productCollectionFactory = $productCollectionFactory;
		$this->_scopeConfig = $scopeConfig;
		parent::__construct($context, $data);
    }

    /**
     * Return categories helper
     */
	public function getCollection(){
		$collection = $this->_productCollectionFactory->create();
        $collection->addAttributeToSelect('*');
		$collection->addFieldToFilter('visibility', '4');
		$collection->addFieldToFilter('status', '1');
		$collection->addFieldToFilter('is_featured', '1');
        return $collection;
		
	}	
	public function getSectionStatus() {
        return $this->_scopeConfig->getValue('featureproduct_settings/featured_products/enable', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }
	
}