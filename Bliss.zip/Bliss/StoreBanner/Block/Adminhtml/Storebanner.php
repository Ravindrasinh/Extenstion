<?php
namespace Bliss\StoreBanner\Block\Adminhtml;
class Storebanner extends \Magento\Backend\Block\Widget\Grid\Container
{
    /**
     * Constructor
     *
     * @return void
     */
    protected function _construct()
    {
		
        $this->_controller = 'adminhtml_storebanner';/*block grid.php directory*/
        $this->_blockGroup = 'Bliss_StoreBanner';
        $this->_headerText = __('Storebanner');
        $this->_addButtonLabel = __('Add New Entry'); 
        parent::_construct();
		
    }
}