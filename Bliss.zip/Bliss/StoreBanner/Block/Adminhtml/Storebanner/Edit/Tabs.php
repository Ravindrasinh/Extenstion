<?php
namespace Bliss\StoreBanner\Block\Adminhtml\Storebanner\Edit;

class Tabs extends \Magento\Backend\Block\Widget\Tabs
{
    protected function _construct()
    {
		
        parent::_construct();
        $this->setId('checkmodule_storebanner_tabs');
        $this->setDestElementId('edit_form');
        $this->setTitle(__('Storebanner Information'));
    }
}