<?php
/**
 * Copyright © 2015 Bliss . All rights reserved.
 */
namespace Bliss\StoreBanner\Block\Storebanner;
use Bliss\StoreBanner\Block\BaseBlock;
class Index extends BaseBlock
{
	public $hello='Hello World';
	
	public function getstorebanner(){
		$objectManager =   \Magento\Framework\App\ObjectManager::getInstance();
		
		$objectManager =   \Magento\Framework\App\ObjectManager::getInstance();
		$productCollection = $objectManager->create('Bliss\StoreBanner\Model\ResourceModel\Storebanner\CollectionFactory');
		$collection = $productCollection->create();
		$collection->addFieldToFilter('status', '1');
		return $collection;
	}
}
