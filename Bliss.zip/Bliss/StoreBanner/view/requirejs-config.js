var config = {
    map: {
        '*': {
            bxslider: 'Bliss_Storebanner/js/jquery.bxslider.min.js'
        }
    }
};