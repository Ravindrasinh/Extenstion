<?php
/**
 * Copyright © 2015 Bliss. All rights reserved.
 */
namespace Bliss\StoreBanner\Model\ResourceModel;

/**
 * Storebanner resource
 */
class Storebanner extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Initialize resource
     *
     * @return void
     */
    public function _construct()
    {
        $this->_init('storebanner_storebanner', 'id');
    }

  
}
