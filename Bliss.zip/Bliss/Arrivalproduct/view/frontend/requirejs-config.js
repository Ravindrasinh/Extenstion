/*var config = {
    map: {
        '*': {
            cpowlcarousel: 'Bliss_Featuredproduct/js/owl.carousel'
        }
    }
};*/

var config = {
    map: {
        '*': {
            'bxslider' : 'js/jquery.bxslider'
        }
    }
}
