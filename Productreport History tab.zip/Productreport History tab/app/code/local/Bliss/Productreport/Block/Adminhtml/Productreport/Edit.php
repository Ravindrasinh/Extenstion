<?php

class Bliss_Productreport_Block_Adminhtml_Productreport_Edit extends Mage_Adminhtml_Block_Widget_Form_Container
{
    public function __construct()
    {
        parent::__construct();
                 
        $this->_objectId = 'id';
        $this->_blockGroup = 'productreport';
        $this->_controller = 'adminhtml_productreport';
        
        $this->_updateButton('save', 'label', Mage::helper('productreport')->__('Save Item'));
        $this->_updateButton('delete', 'label', Mage::helper('productreport')->__('Delete Item'));
		
        $this->_addButton('saveandcontinue', array(
            'label'     => Mage::helper('adminhtml')->__('Save And Continue Edit'),
            'onclick'   => 'saveAndContinueEdit()',
            'class'     => 'save',
        ), -100);

        $this->_formScripts[] = "
            function toggleEditor() {
                if (tinyMCE.getInstanceById('productreport_content') == null) {
                    tinyMCE.execCommand('mceAddControl', false, 'productreport_content');
                } else {
                    tinyMCE.execCommand('mceRemoveControl', false, 'productreport_content');
                }
            }

            function saveAndContinueEdit(){
                editForm.submit($('edit_form').action+'back/edit/');
            }
        ";
    }

    public function getHeaderText()
    {
        if( Mage::registry('productreport_data') && Mage::registry('productreport_data')->getId() ) {
            return Mage::helper('productreport')->__("Edit Item '%s'", $this->htmlEscape(Mage::registry('productreport_data')->getTitle()));
        } else {
            return Mage::helper('productreport')->__('Add Item');
        }
    }
}