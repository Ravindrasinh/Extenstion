<?php
class Bliss_Productreport_Block_Productreport extends Mage_Core_Block_Template
{
	public function _prepareLayout()
    {
		return parent::_prepareLayout();
    }
    
   
	
}