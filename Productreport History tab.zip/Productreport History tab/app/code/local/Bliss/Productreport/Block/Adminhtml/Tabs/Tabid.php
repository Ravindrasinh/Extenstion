<?php
class Bliss_Productreport_Block_Adminhtml_Tabs_Tabid extends Mage_Adminhtml_Block_Widget
{
    public function __construct()
    {
        parent::__construct();
        $this->setTemplate('productreport/newtab.phtml');
    }
	Public function getProducthistory($id){
		$collection = Mage::getModel('productreport/productreport')->getCollection()
			->addFieldToFilter('productid', array('eq' => $id));
		
		return $collection;
	}
  
}