<?php

class Bliss_Productreport_Block_Adminhtml_Productreport_Edit_Tabs extends Mage_Adminhtml_Block_Widget_Tabs
{

  public function __construct()
  {
      parent::__construct();
      $this->setId('productreport_tabs');
      $this->setDestElementId('edit_form');
      $this->setTitle(Mage::helper('productreport')->__('Item Information'));
  }

  protected function _beforeToHtml()
  {
      $this->addTab('form_section', array(
          'label'     => Mage::helper('productreport')->__('Item Information'),
          'title'     => Mage::helper('productreport')->__('Item Information'),
          'content'   => $this->getLayout()->createBlock('productreport/adminhtml_productreport_edit_tab_form')->toHtml(),
      ));
     
      return parent::_beforeToHtml();
  }
}