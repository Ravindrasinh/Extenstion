<?php
class Bliss_Productreport_Block_Adminhtml_Productreport extends Mage_Adminhtml_Block_Widget_Grid_Container{
	public function __construct()
	{
		$this->_controller = 'adminhtml_productreport';
		$this->_blockGroup = 'productreport';
		$this->_headerText = Mage::helper('productreport')->__('Item Manager');
		$this->_addButtonLabel = Mage::helper('productreport')->__('Add Item');
		parent::__construct();
	}
	
}