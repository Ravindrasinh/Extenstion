<?php
class Bliss_Productreport_IndexController extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {
    	
    	/*
    	 * Load an object by id 
    	 * Request looking like:
    	 * http://site.com/productreport?id=15 
    	 *  or
    	 * http://site.com/productreport/id/15 	
    	 */
    	/* 
		$productreport_id = $this->getRequest()->getParam('id');

  		if($productreport_id != null && $productreport_id != '')	{
			$productreport = Mage::getModel('productreport/productreport')->load($productreport_id)->getData();
		} else {
			$productreport = null;
		}	
		*/
		
		 /*
    	 * If no param we load a the last created item
    	 */ 
    	/*
    	if($productreport == null) {
			$resource = Mage::getSingleton('core/resource');
			$read= $resource->getConnection('core_read');
			$productreportTable = $resource->getTableName('productreport');
			
			$select = $read->select()
			   ->from($productreportTable,array('productreport_id','title','content','status'))
			   ->where('status',1)
			   ->order('created_time DESC') ;
			   
			$productreport = $read->fetchRow($select);
		}
		Mage::register('productreport', $productreport);
		*/

			
		$this->loadLayout();     
		$this->renderLayout();
    }
}