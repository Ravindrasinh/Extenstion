<?php

class Bliss_Productreport_Model_Productreport extends Mage_Core_Model_Abstract
{
    public function _construct()
    {
        parent::_construct();
        $this->_init('productreport/productreport');
    }
}