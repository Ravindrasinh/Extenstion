<?php 
class Bliss_Productreport_Model_Observer{
	
	public function catalog_product_save_after($observer)
    {
		
		$_user = Mage::getSingleton('admin/session');
		$_product = $observer->getProduct(); 
		$product_id = $_product->getId();
		$update_time = now();
		$username = $_user->getUser()->getFirstname().' '.$_user->getUser()->getLastname();
          
		
		
		$data = array('productid' => $product_id, 'user'=> $username, 'update_time'=> now()) ;			
		$model = Mage::getModel('productreport/productreport');
		$model->setData($data);
		$model->save();
	}	

}

