<?php

$installer = $this;

$installer->startSetup();

$installer->run("

-- DROP TABLE IF EXISTS {$this->getTable('productreport')};
CREATE TABLE {$this->getTable('productreport')} (
  `productreport_id` int(11) unsigned NOT NULL auto_increment,
  `productid` int(11) ,
  `user` text NOT NULL default '',
  `update_time` datetime NULL,
  PRIMARY KEY (`productreport_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

    ");

$installer->endSetup(); 