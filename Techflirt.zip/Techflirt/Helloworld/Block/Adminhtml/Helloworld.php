<?php
class Techflirt_Helloworld_Block_Adminhtml_Helloworld extends Mage_Adminhtml_Block_Widget_Grid_Container
{
  public function __construct()
  {
    $this->_controller = 'adminhtml_helloworld';
    $this->_blockGroup = 'helloworld';
    $this->_headerText = Mage::helper('helloworld')->__('Item Manager');
    $this->_addButtonLabel = Mage::helper('helloworld')->__('Add Item');
    parent::__construct();
  }
}