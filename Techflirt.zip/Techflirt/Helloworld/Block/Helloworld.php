<?php
class Techflirt_Helloworld_Block_Helloworld extends Mage_Core_Block_Template
{
	public function _prepareLayout()
    {
		return parent::_prepareLayout();
    }
    
     public function getHelloworld()     
     { 
        if (!$this->hasData('helloworld')) {
            $this->setData('helloworld', Mage::registry('helloworld'));
        }
        return $this->getData('helloworld');
        
    }
}