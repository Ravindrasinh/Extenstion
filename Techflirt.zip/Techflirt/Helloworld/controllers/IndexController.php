<?php
class Techflirt_Helloworld_IndexController extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {
    	
    	/*
    	 * Load an object by id 
    	 * Request looking like:
    	 * http://site.com/helloworld?id=15 
    	 *  or
    	 * http://site.com/helloworld/id/15 	
    	 */
    	/* 
		$helloworld_id = $this->getRequest()->getParam('id');

  		if($helloworld_id != null && $helloworld_id != '')	{
			$helloworld = Mage::getModel('helloworld/helloworld')->load($helloworld_id)->getData();
		} else {
			$helloworld = null;
		}	
		*/
		
		 /*
    	 * If no param we load a the last created item
    	 */ 
    	/*
    	if($helloworld == null) {
			$resource = Mage::getSingleton('core/resource');
			$read= $resource->getConnection('core_read');
			$helloworldTable = $resource->getTableName('helloworld');
			
			$select = $read->select()
			   ->from($helloworldTable,array('helloworld_id','title','content','status'))
			   ->where('status',1)
			   ->order('created_time DESC') ;
			   
			$helloworld = $read->fetchRow($select);
		}
		Mage::register('helloworld', $helloworld);
		*/

			
		$this->loadLayout();     
		$this->renderLayout();
    }
}