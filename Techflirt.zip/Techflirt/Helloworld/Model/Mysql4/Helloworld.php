<?php

class Techflirt_Helloworld_Model_Mysql4_Helloworld extends Mage_Core_Model_Mysql4_Abstract
{
    public function _construct()
    {    
        // Note that the helloworld_id refers to the key field in your database table.
        $this->_init('helloworld/helloworld', 'helloworld_id');
    }
}