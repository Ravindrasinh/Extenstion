<?php
class Bliss_Register_Block_Adminhtml_Register extends Mage_Adminhtml_Block_Widget_Grid_Container
{
  public function __construct()
  {
    $this->_controller = 'adminhtml_register';
    $this->_blockGroup = 'register';
    $this->_headerText = Mage::helper('register')->__('Item Manager');
    $this->_addButtonLabel = Mage::helper('register')->__('Add Item');
    parent::__construct();
  }
}