<?php

class Bliss_Register_Block_Adminhtml_Register_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form
{
  protected function _prepareForm()
  {
      $form = new Varien_Data_Form();
      $this->setForm($form);
      $fieldset = $form->addFieldset('register_form', array('legend'=>Mage::helper('register')->__('Item information')));
     
      $fieldset->addField('title', 'text', array(
          'label'     => Mage::helper('register')->__('Title'),
          'class'     => 'required-entry',
          'required'  => true,
          'name'      => 'title',
      ));

      $fieldset->addField('filename', 'file', array(
          'label'     => Mage::helper('register')->__('File'),
          'required'  => false,
          'name'      => 'filename',
	  ));
		
      $fieldset->addField('status', 'select', array(
          'label'     => Mage::helper('register')->__('Status'),
          'name'      => 'status',
          'values'    => array(
              array(
                  'value'     => 1,
                  'label'     => Mage::helper('register')->__('Enabled'),
              ),

              array(
                  'value'     => 2,
                  'label'     => Mage::helper('register')->__('Disabled'),
              ),
          ),
      ));
     
      $fieldset->addField('content', 'editor', array(
          'name'      => 'content',
          'label'     => Mage::helper('register')->__('Content'),
          'title'     => Mage::helper('register')->__('Content'),
          'style'     => 'width:700px; height:500px;',
          'wysiwyg'   => false,
          'required'  => true,
      ));
     
      if ( Mage::getSingleton('adminhtml/session')->getRegisterData() )
      {
          $form->setValues(Mage::getSingleton('adminhtml/session')->getRegisterData());
          Mage::getSingleton('adminhtml/session')->setRegisterData(null);
      } elseif ( Mage::registry('register_data') ) {
          $form->setValues(Mage::registry('register_data')->getData());
      }
      return parent::_prepareForm();
  }
}