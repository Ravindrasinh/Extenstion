<?php
class Bliss_Register_Block_Register extends Mage_Core_Block_Template
{
	public function _prepareLayout()
    {
		return parent::_prepareLayout();
    }
    
     public function getRegister()     
     { 
        if (!$this->hasData('register')) {
            $this->setData('register', Mage::registry('register'));
        }
        return $this->getData('register');
        
    }
}