<?php
class Bliss_Register_IndexController extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {
    	
    	/*
    	 * Load an object by id 
    	 * Request looking like:
    	 * http://site.com/register?id=15 
    	 *  or
    	 * http://site.com/register/id/15 	
    	 */
    	/* 
		$register_id = $this->getRequest()->getParam('id');

  		if($register_id != null && $register_id != '')	{
			$register = Mage::getModel('register/register')->load($register_id)->getData();
		} else {
			$register = null;
		}	
		*/
		
		 /*
    	 * If no param we load a the last created item
    	 */ 
    	/*
    	if($register == null) {
			$resource = Mage::getSingleton('core/resource');
			$read= $resource->getConnection('core_read');
			$registerTable = $resource->getTableName('register');
			
			$select = $read->select()
			   ->from($registerTable,array('register_id','title','content','status'))
			   ->where('status',1)
			   ->order('created_time DESC') ;
			   
			$register = $read->fetchRow($select);
		}
		Mage::register('register', $register);
		*/
        
		
		$this->loadLayout();     
		$this->renderLayout();
    }
	
	public function saveAction()
	{
		$data = $this->getRequest()->getPost();
		
		//print_r($data);
		//Exit;
		
			if(isset($_FILES['filename']['name']) && $_FILES['filename']['name'] != '') {
				try {	
					/* Starting upload */	
					$uploader = new Varien_File_Uploader('filename');
					
					// Any extention would work
	           		$uploader->setAllowedExtensions(array('jpg','jpeg','gif','png'));
					$uploader->setAllowRenameFiles(false);
					
					// Set the file upload mode 
					// false -> get the file directly in the specified folder
					// true -> get the file in the product like folders 
					//	(file.jpg will go in something like /media/f/i/file.jpg)
					$uploader->setFilesDispersion(false);
							
					// We set media as the upload dir
					$path = Mage::getBaseDir('media') . DS . 'images';
					$uploader->save($path, $_FILES['filename']['name'] );
					
				} catch (Exception $e) {
		      
		        }
	        
		        //this way the name is saved in DB
	  			$data['filename'] = $_FILES['filename']['name'];
			}
			
			try{
			
			$model = Mage::getModel('register/register');
			$model->setData($data);
			
			$model->save();
			
			Mage::getSingleton('core/session')->addSuccess(Mage::helper('register')->__('Item was successfully saved'));
			Mage::getSingleton('core/session')->setFormData(false);
			
			$this->_redirect('*/*/');
			return;		
		
			} catch (Exception $e) {
			
			Mage::getSingleton('core/session')->addError($e->getMessage());
			Mage::getSingleton('core/session')->setFormData($data);
			$this->_redirect('*/*/edit', array('id' => $this->getRequest()->getParam('id')));
			Mage::getSingleton('core/session')->addError(Mage::helper('register')->__('Unable to find item to save'));
			return;
			
		}
		
         $this->_redirect('*/*/');
	}
	public function editAction() {
		
		
		$this->loadLayout(); 
		
		$id = $this->getRequest()->getParam('id');
		$model=Mage::getModel('register/register')->load($id);
		
		//print_r($model->getData());
		
	    $this->renderLayout(); 
		
	} 
  public function updateAction(){
	  
	  $id = $this->getRequest()->getParam('id');
		$model=Mage::getModel('register/register')->load($id);
	  $data = $this->getRequest()->getPost();
	  $response = array();
		
		//print_r($data);
		//Exit;
		
			if(isset($_FILES['filename']['name']) && $_FILES['filename']['name'] != '') {
				try {	
					/* Starting upload */	
					$uploader = new Varien_File_Uploader('filename');
					
					// Any extention would work
	           		$uploader->setAllowedExtensions(array('jpg','jpeg','gif','png'));
					$uploader->setAllowRenameFiles(false);
					
					// Set the file upload mode 
					// false -> get the file directly in the specified folder
					// true -> get the file in the product like folders 
					//	(file.jpg will go in something like /media/f/i/file.jpg)
					$uploader->setFilesDispersion(false);
							
					// We set media as the upload dir
					$path = Mage::getBaseDir('media') . DS . 'images';
					$uploader->save($path, $_FILES['filename']['name'] );
					
				} catch (Exception $e) {
		      
		        }
	        
		        //this way the name is saved in DB
	  			$data['filename'] = $_FILES['filename']['name'];
			}
			
			try{
			
			$model = Mage::getModel('register/register');
			$model->setData($data)->setId($id);;
			
			$model->save();
			
			$block = $this->getLayout()->createBlock('register/register')->setTemplate('register/register1.phtml')->toHtml();
			$response['block'] = $block;
			$response['message'] = "successfully added";
			$response['status'] = "success";
			
			Mage::getSingleton('core/session')->addSuccess(Mage::helper('register')->__('Item was successfully Updated'));
			Mage::getSingleton('core/session')->setFormData(false);
			
			$this->_redirect('*/*/');
			return;		
		
			} catch (Exception $e) {
			
			Mage::getSingleton('core/session')->addError($e->getMessage());
			Mage::getSingleton('core/session')->setFormData($data);
			$this->_redirect('*/*/edit', array('id' => $this->getRequest()->getParam('id')));
			Mage::getSingleton('core/session')->addError(Mage::helper('register')->__('Unable to find item to save'));
			return;
			
		}
		
         $this->_redirect('*/*/');
    }
	
	public function deleteAction(){
		if( $this->getRequest()->getParam('id') > 0 ) {
			try {
				$model = Mage::getModel('register/register');
				 
				$model->setId($this->getRequest()->getParam('id'))
					->delete();
					 
				Mage::getSingleton('core/session')->addSuccess(Mage::helper('register')->__('Item was successfully deleted'));
				$this->_redirect('*/*/');
			} catch (Exception $e) {
				Mage::getSingleton('core/session')->addError($e->getMessage());
				$this->_redirect('*/*/edit', array('id' => $this->getRequest()->getParam('id')));
			}
		}
		$this->_redirect('*/*/');
	}

}